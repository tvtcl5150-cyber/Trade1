# Bullex Signal — protótipo

Abra `index.html` no navegador.

O protótipo:
- mostra candles simulados;
- calcula EMA 9/21 e RSI;
- pontua tendência, candle e rompimento;
- exibe COMPRA, VENDA ou AGUARDAR;
- registra um histórico de sinais;
- não acessa a conta Bullex e não envia ordens.

Para transformar em versão real, é necessário conectar uma fonte autorizada/confiável de candles da Bullex e validar a estratégia com backtest.
